package com.example.android.irrigationsystem;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    TextView l, t, h, p, d;
    Button on, off;
private JsonPlaceHolderAPI jsonPlaceHolderAPI;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        l = findViewById(R.id.l_tv);
        t = findViewById(R.id.t_tv);
        h = findViewById(R.id.h_tv);
        p = findViewById(R.id.pumb_tv);
        d = findViewById(R.id.d_tv);
        on = findViewById(R.id.on);
        off = findViewById(R.id.off);
        on.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                update();

            }
        });
        off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                p.setText("0");

            }
        });

        Gson gson = new GsonBuilder()
                .setLenient()
                .create();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(JsonPlaceHolderAPI.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

         jsonPlaceHolderAPI = retrofit.create(JsonPlaceHolderAPI.class);
         getInfo();
       // getInfo1();
       // createWaterSystem();

            }
    private void getInfo(){
        Call<List<water_system>> call = jsonPlaceHolderAPI.getInfo();
        call.enqueue(new Callback<List<water_system>>() {
            @Override
            public void onResponse(Call<List<water_system>> call, Response<List<water_system>> response) {
                if (!response.isSuccessful()) {
                    d.setText(response.code());
                    return;
                } else {
                    List<water_system> sysInfo = response.body();

                    for (water_system i : sysInfo) {
                        //  "ID"+i.getId() + "\n"+
                        l.setText(i.getLevel());
                        t.setText(i.getTemp());
                        h.setText(i.getHumidity());
                        p.setText(i.getPump());
                        d.setText(i.getDate());
                    }
                }
            }

            @Override
            public void onFailure(Call<List<water_system>> call, Throwable t) {
                Log.e("tag", t.getMessage());
                //  Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void getInfo1(){
        Call<List<water_system>> call= jsonPlaceHolderAPI.getInfo1(1);
        call.enqueue(new Callback<List<water_system>>() {
            @Override
            public void onResponse(Call<List<water_system>> call, Response<List<water_system>> response) {
                List<water_system> sysInfo = response.body();
                if (!response.isSuccessful()) {
                    d.setText("Code: "+ response.code());
                    return;
                }
                else {
                    for (water_system i : sysInfo) {
                        //  "ID"+i.getId() + "\n"+
                        l.setText(i.getLevel());
                        t.setText(i.getTemp());
                        h.setText(i.getHumidity());
                        p.setText(i.getPump());
                        d.setText(i.getDate());
                    }
                }

            }

            @Override
            public void onFailure(Call<List<water_system>> call, Throwable t) {
                Log.e("tag", t.getMessage());

            }
        });
    }
    private void createWaterSystem(){
        water_system w= new water_system("32","32","2","0");
        Call<water_system> call = jsonPlaceHolderAPI.createWaterSystem(w);
        call.enqueue(new Callback<water_system>() {
            @Override
            public void onResponse(Call<water_system> call, Response<water_system> response) {
                if (!response.isSuccessful()) {
                    d.setText("Code: "+ response.code());
                    return;
                }
                else {
                    water_system sysInfo = response.body();


                        //  "ID"+i.getId() + "\n"+
                        l.setText(sysInfo.getLevel());
                        t.setText(sysInfo.getTemp());
                        h.setText(sysInfo.getHumidity());
                        p.setText(sysInfo.getPump());
                        d.setText("Cod: "+response.code());
                       // d.setText(sysInfo.getDate());

                }
            }

            @Override
            public void onFailure(Call<water_system> call, Throwable t) {
                Log.e("tag", t.getMessage());

            }
        });
    }
    private void update(){
        water_system w =new water_system("45","56","56","0");
        Call<water_system> call = jsonPlaceHolderAPI.Update(1,w);
        call.enqueue(new Callback<water_system>() {
            @Override
            public void onResponse(Call<water_system> call, Response<water_system> response) {
                if (!response.isSuccessful()) {
                    d.setText("Code: "+ response.code());
                    return;
                }
                else {
                    water_system sysInfo = response.body();


                    //  "ID"+i.getId() + "\n"+
                    l.setText(sysInfo.getLevel());
                    t.setText(sysInfo.getTemp());
                    h.setText(sysInfo.getHumidity());
                    p.setText(sysInfo.getPump());
                    d.setText("Cod: "+response.code());
                    // d.setText(sysInfo.getDate());

                }
            }

            @Override
            public void onFailure(Call<water_system> call, Throwable t) {
                Log.e("tag", t.getMessage());

            }
        });
    }

}
