package com.example.android.irrigationsystem;

public class water_system {
    private Integer id;
    private String level;
    private String temp;
       private String humidity;
    private String pump;
    private String reg_date;

    public water_system(String level, String temp, String humidity, String pump) {
        this.level = level;
        this.temp = temp;
        this.humidity = humidity;
        this.pump = pump;
    }

    public int getId() {
        return id;
    }

    public String getTemp() {
        return temp;
    }

    public String getLevel() {
        return level;
    }

    public String getHumidity() {
        return humidity;
    }

    public String getDate() { return reg_date;}

    public String getPump() {
        return pump;
    }
}
